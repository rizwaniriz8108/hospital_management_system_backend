package com.admin.service;

import com.admin.model.EmailDetails;

public interface   EmailService {

	
	String sendSimpleMail(EmailDetails details);
    
}
