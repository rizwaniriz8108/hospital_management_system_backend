package com.admin.util;

public class Constant {
	
public static final String Inactive = "Inactive";

public static final String Active = "Active";

public static final String USER_SERVICE_BASE_URL = "http://IAM-SERVICE";

}
