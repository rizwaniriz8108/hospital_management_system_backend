package com.admin.exception;

public class UserRecordNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserRecordNotFoundException() {
		super();
	}

	public UserRecordNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
