package com.admin.exception;

public class UnAuthorizeException extends RuntimeException{

	UnAuthorizeException(String message){
		super(message);
	}
	
}
