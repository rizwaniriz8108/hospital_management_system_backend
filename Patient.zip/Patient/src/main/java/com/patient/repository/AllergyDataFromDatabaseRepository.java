package com.patient.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface AllergyDataFromDatabaseRepository{ 

	
}
