package com.pms.service;

public interface EmailService {

	
	 String sendSimpleMail(String recipientEmailId, String defaultPassword, String firstname, boolean isForgotPassword);
    
}
